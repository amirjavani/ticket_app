import 'package:mogodb_project/ticket.dart';

class User {
  late int _id;
  late String userName;
  late String email;
  late String fullName;
  late String phone;
  late String password;
  late String address;
  late List<Ticket> tikets;
}
