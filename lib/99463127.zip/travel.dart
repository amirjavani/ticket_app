import 'dart:ffi';

class Travel {
  late int _id;
  late int bussID;
  late String bussName;
  late String des;
  late String origin;
  late String date;
  late Float price;
  late int totalCapacity;
  late int capacity;
}
