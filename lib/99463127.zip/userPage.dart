import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'main.dart';

class UserPage extends StatefulWidget {
  const UserPage({Key? key}) : super(key: key);

  @override
  State<UserPage> createState() => _UserPageState();
}

class _UserPageState extends State<UserPage> {
  TextEditingController desCon = TextEditingController();
  TextEditingController originCon = TextEditingController();
  TextEditingController dateCon = TextEditingController();
  TextEditingController codeCon = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('admin'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8.0),
              child: TextField(
                controller: originCon,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'origin',
                  contentPadding: EdgeInsets.all(20),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8.0),
              child: TextField(
                controller: desCon,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'destination',
                  contentPadding: EdgeInsets.all(20),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8.0),
              child: TextField(
                controller: dateCon,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'destination',
                  contentPadding: EdgeInsets.all(20),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            ElevatedButton(
                onPressed: () async {
                  var db = MyApp.db;
                  await db.open();
                  List travels = await db.collection('travels').find({
                    'des': desCon.text,
                    'origin': originCon.text,
                    'date': dateCon.text
                  }).toList();
                  if (travels.isNotEmpty) {
                    travels.forEach((travel) {
                      print(
                          'buss code: ${travel['bussCode']} - buss kind : ${travel['bussKind']} - buss company  : ${travel['bussCompany']} - price : ${travel['price']} - capacity : ${travel['capacity']} - departure time : ${travel['time']}');
                    });
                  }
                  await db.close();
                },
                child: Text('search')),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8.0),
              child: TextField(
                controller: codeCon,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'buss code to buy',
                  contentPadding: EdgeInsets.all(20),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            ElevatedButton(
                onPressed: () async {
                  var db = MyApp.db;
                  await db.open();
                  await db.collection('travels').find({
                    'bussCode': codeCon.text,
                  }).forEach((element) async {
                    getTicket(element);
                  });

                  await db.close();
                },
                child: Text('buy')),
          ],
        ),
      ),
    );
  }

  Future<void> getTicket(var element) async {
    if (element['capacity'] > 0) {
      var db = MyApp.db;
      var db2 = MyApp.db2;
      await db.collection('users').updateOne({
        'username': MyApp.userName,
      }, {
        '\$push': {
          'tickets': {
            'date': element['date'],
            'chair': element['capacity'],
            'origin': element['origin'],
            'des': element['des'],
            'time': element['time'],
            'price': element['price'],
            'bussCode': element['bussCode']
          }
        }
      });
      await db.collection('travels').updateOne({
        'bussCode': codeCon.text,
      }, {
        '\$inc': {'capacity': -1}
      });
      print(MyApp.userName);
      await db2.collection('users').updateOne({
        'username': MyApp.userName,
      }, {
        '\$push': {
          'tickets': {
            'date': element['date'],
            'chair': element['capacity'],
            'origin': element['origin'],
            'des': element['des'],
            'time': element['time'],
            'price': element['price'],
            'bussCode': element['bussCode']
          }
        }
      });
    } else {
      print('this buss is full');
    }
  }
}
