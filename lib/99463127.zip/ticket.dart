import 'dart:ffi';

class Ticket {
  late int _id;
  late int bussID;
  late int chairNum;
  late String bussName;
  late String des;
  late String origin;
  late String date;
  late Float price;
}
